[ ] Add Icons
[ ] Add styles for background
[ ] hexagonal buttons
[ ] Create main page styles
[ ] Month column 
[ ] Generate column
[ ] hover effects on days
[ ] Select icons/activity
[ ] Style background
[ ] add seperator between days
[ ] Add activity text in header text area
[ ] Swap from different activities. 
[ ] store status in local
[ ] create database to store user data
[ ] Select from activities to focus on.
[ ] Track start/stop data 
[ ] Redo Design
[ ] Add active states
[ ] 